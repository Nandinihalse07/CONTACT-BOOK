# Simple Calculator - TASK 2

The **Simple Calculator**  performs basic arithmetic operations. Users can input two numbers and choose an operation (addition, subtraction, multiplication, division, modulus, floor division or power). Here's how it works:

1. **User Input:**
   - The user is prompted to input two numbers.
   - They also select an operation (e.g., + for addition, - for subtraction, * for multiplication, / for division,% for modulus,// for floor division, ** for power).

2. **Perform Calculation:**
   - Based on the user's input, the application performs the chosen arithmetic operation.
   - For example:
     - If the user inputs `5`, `3`, and selects `+`, the result is `8`.
     - If the user inputs `10`, `4`, and selects `-`, the result is `6`.
     - If the user inputs `7`, `2`, and selects `*`, the result is `14`.
     - If the user inputs `15`, `5`, and selects `/`, the result is `3.0`.
     - If the user inputs `5`, `5`, and selects `%`, the result is `0.0`.
     - If the user inputs `15`, `5`, and selects `//`, the result is `3.0`.
     -  If the user inputs `3`, `2`, and selects `**`, the result is `9.0`.

3. **Display Result:**
   - The calculated result is displayed on the screen.
